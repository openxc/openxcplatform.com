#include "util/log.h"

const int openxc::util::log::MAX_LOG_LINE_LENGTH = 120;
