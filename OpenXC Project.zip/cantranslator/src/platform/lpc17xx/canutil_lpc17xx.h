#ifndef __CANUTIL_LPC17XX__
#define __CANUTIL_LPC17XX__

#include "lpc17xx_can.h"

#define CAN_CONTROLLER(bus) ((LPC_CAN_TypeDef*)bus->controller)

#endif // __CANUTIL_LPC17XX__
