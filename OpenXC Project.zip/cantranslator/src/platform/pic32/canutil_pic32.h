#ifndef __CANUTIL__PIC32__
#define __CANUTIL__PIC32__

#include "chipKITCAN.h"

#define SYS_FREQ (80000000L)
#define CAN_CONTROLLER(bus) ((CAN*)bus->controller)

#endif // __CANUTIL__PIC32__
