#include "util/timer.h"

void openxc::util::time::delayMs(unsigned long delayInMs) { }

unsigned long openxc::util::time::systemTimeMs() {
    return 0;
}

void openxc::util::time::initialize() { }
