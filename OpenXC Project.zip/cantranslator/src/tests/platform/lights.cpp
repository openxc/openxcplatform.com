#include "lights.h"

void openxc::lights::enable(Light light, RGB color) { }

void openxc::lights::initialize() { }
