#include "can/canwrite.h"

bool openxc::can::write::sendMessage(CanBus* bus, CanMessage request) { }
