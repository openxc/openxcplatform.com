/**
 * This is the top-level package of the OpenXC library. It contains the
 * primary entry point for applications, the {@link com.openxc.VehicleManager}.
 */
package com.openxc;
