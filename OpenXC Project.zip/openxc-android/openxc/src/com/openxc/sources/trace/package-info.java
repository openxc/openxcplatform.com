/**
 * Contains a vehicle data source implementation that reads from OpenXC trace
 * files. This source is most often used for bench testing.
 */
package com.openxc.sources.trace;
