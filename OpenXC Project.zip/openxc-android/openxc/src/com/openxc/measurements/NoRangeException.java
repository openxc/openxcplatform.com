package com.openxc.measurements;

public class NoRangeException extends Exception {
	private static final long serialVersionUID = -911377848172518495L;
}
