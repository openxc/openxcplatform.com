/**
 * Classes capable of serializing Measurement objects to another format.
 */
package com.openxc.measurements.serializers;
