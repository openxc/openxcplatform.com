package com.openxc.measurements.serializers;

public interface MeasurementSerializer {
}
