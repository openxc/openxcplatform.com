/**
 * Contains the classes for connecting to a vehicle interface via Bluetooth.
 */
package com.openxc.interfaces.bluetooth;
