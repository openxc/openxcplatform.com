/**
 * A collection of unit classes used to avoid making false assumptions about
 * the unit of values received from the vehicle.
 */
package com.openxc.units;
